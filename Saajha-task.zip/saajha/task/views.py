from rest_framework import routers, serializers, viewsets
from django.shortcuts import render, redirect
from django.http import HttpResponse
from. models import signup
from .serializers import taskserializer

# Create your views here.


def index(request):
    return render(request, 'home.html')


def signIn(request):
    if request.method == "POST":

        email_id = request.POST.get('email')
        pass_word = request.POST.get('pwd')

        print(email_id, "-----", pass_word, "------")

        save_info = signup(email=email_id, password=pass_word)
        save_info.save()
        return HttpResponse("success")
        # return redirect('home')


class serializerview(viewsets.ModelViewSet):
    queryset = signup.objects.all()
    serializer_class = taskserializer
