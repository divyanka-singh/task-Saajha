from django.db import models
from email.policy import default

# Create your models here.


class signup(models.Model):
    email = models.CharField(max_length=100, default="")
    password = models.CharField(max_length=100, default="")

    def __str__(self):
        return self.email
